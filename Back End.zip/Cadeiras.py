from datetime import datetime  # Biblioteca utilizada para manipular datas e horários.
import psycopg2  # Biblioteca utilizada para estabelecer a conexão com o PostgreSQL.


# Estabelece a conexão com o banco de dados utilizando as informações fornecidas.
def conectar():
    try:
        conn = psycopg2.connect(
            database='CINEMAX',
            host='127.0.0.1',
            user='postgres',
            password='postgres'
        )
        return conn
    except psycopg2.Error as e:
        print(f'Erro na conexão ao PostgreSQL: {e}')


def desconectar(conn):
    if conn:
        conn.close()


# Função para cadastrar um novo usuário, e armazenar seus dados no banco.
def cadastrar():
    conn = conectar()
    cursor = conn.cursor()

    cpf = int(input('CPF: '))
    nome = input('Nome: ')
    email = input('Email: ')
    telefone = input('Telefone: ')
    senha = input('Senha: ')

    cursor.execute(f"INSERT INTO cliente (cpf, nome, email, telefone, senha) "
                   f"VALUES ({cpf}, '{nome}', '{email}', {telefone}, '{senha}')")
    conn.commit()


# Verifica se existe um usuário com os valores fornecidos no banco.
def verificar_login(username, password):
    conn = conectar()
    cursor = conn.cursor()

    cursor.execute(f"SELECT * FROM cliente WHERE email = '{username}' AND senha = '{password}'")
    resultado = cursor.fetchone()

    cursor.close()
    conn.close()

    return resultado is not None


# Função lista os filmes disponíveis e a escolha do usuário é salva na variável id_filme_escolhido.
def escolher_filme():
    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("SELECT id_filme, titulo FROM filmes ORDER BY id_filme")
    resultados = cursor.fetchall()

    print('=====FILMES EM CARTAZ=====\n')
    for resultado in resultados:
        id_filme, titulo = resultado
        print(f"{id_filme}-{titulo}\n")

    cursor.close()
    conn.close()

    id_filme_escolhido = int(input("Selecione o ID do filme desejado: "))
    return id_filme_escolhido


# Lista as sessões disponíveis para o filme escolhido pelo usuário.
def escolher_sessao(id_filme_escolhido):
    conn = conectar()
    cursor = conn.cursor()

    cursor.execute(f"SELECT id_sessao, hr_inicio, hr_fim, data_sessao FROM sessao WHERE fk_id_filme={id_filme_escolhido} ORDER BY id_sessao")
    resultados = cursor.fetchall()

    print('==========SESSÕES DISPONÍVEIS==========\n')

    for resultado in resultados:
        id_sessao, hr_inicio, hr_fim, data_sessao = resultado
        # Converter a data para o formato desejado (dia/mês/ano)
        data_sessao_formatada = datetime.strftime(data_sessao, "%d/%m/%Y")
        print(f"Sessão {id_sessao}\nHorário: {hr_inicio} - {hr_fim}\nData: {data_sessao_formatada}\n")

    cursor.close()
    conn.close()

    id_sessao_escolhida = int(input("Selecione o ID da sessão desejada: "))
    return id_sessao_escolhida


# Mostra as cadeiras disponíveis e permite ao usuário escolher o número da cadeira desejada.
def escolher_cadeira(id_sessao_escolhida):
    conn = conectar()
    cursor = conn.cursor()

    # Consultar as cadeiras disponíveis na sessão selecionada
    cursor.execute(f"SELECT c.id_cadeira, c.nr_cadeira, c.disponivel FROM cadeiras as c WHERE c.fk_id_sessao = {id_sessao_escolhida} ORDER BY c.id_cadeira ")
    resultados = cursor.fetchall()

    print('==========CADEIRAS DISPONÍVEIS==========\n')

    # Número de cadeiras exibidas por linha
    cadeiras_por_linha = 10
    count = 0

    for resultado in resultados:
        _, nr_cadeira, disponivel = resultado
        print(f"{nr_cadeira}\t" if disponivel else "X\t", end="")
        count += 1

        if count % cadeiras_por_linha == 0:
            print()  # Pula para a próxima linha após exibir um número de cadeiras definido
            print()  # Pula uma linha adicional no final

    # Solicitar ao usuário que escolha uma cadeira disponível
    while True:
        nr_cadeira_escolhida = int(input("Selecione o número da cadeira desejada: "))

        cadeira_disponivel = False
        for _, nr_cadeira, disponivel in resultados:
            if nr_cadeira == nr_cadeira_escolhida and disponivel:
                cadeira_disponivel = True
                break

        if cadeira_disponivel:
            print(f"Cadeira {nr_cadeira_escolhida} selecionada.")
            break
        else:
            print("\nCadeira indisponível. Por favor, escolha uma cadeira disponível.\n")

    cursor.execute(f"UPDATE cadeiras SET disponivel = False WHERE nr_cadeira = {nr_cadeira_escolhida} AND fk_id_sessao = {id_sessao_escolhida}")
    conn.commit()

    cursor.close()
    conn.close()

    return nr_cadeira_escolhida


# Solicita ao usuário a escolha do tipo de ingresso
def escolher_tipo_ingresso():
    print('==========TIPOS DE INGRESSO==========')
    print('1 - Inteira')
    print('2 - Meia')
    tipo_ingresso = int(input("\nSelecione o tipo de ingresso desejado: "))
    return tipo_ingresso


# Mostra um resumo dos ingressos escolhidos pelo usuário e o valor total.
def exibir_resumo_ingresso(ingressos):
    valor_total = 0
    print('\n==========RESUMO DOS INGRESSOS==========')

    conn = conectar()
    cursor = conn.cursor()

    for ingresso in ingressos:
        id_filme, id_sessao, nr_cadeira, tipo_ingresso = ingresso

        # Consultar informações do ingresso em uma única consulta
        cursor.execute("SELECT f.titulo, s.hr_inicio, s.hr_fim, s.data_sessao, ti.preco "
                       "FROM filmes f "
                       "JOIN sessao s ON f.id_filme = s.fk_id_filme "
                       "JOIN tipo_ingresso ti ON ti.id_tipo_ingresso = %s "
                       "WHERE f.id_filme = %s AND s.id_sessao = %s",
                       (tipo_ingresso, id_filme, id_sessao))
        ingresso_info = cursor.fetchone()

        if ingresso_info:
            titulo_filme, hr_inicio, hr_fim, data_sessao, valor_ingresso = ingresso_info

            # Convertendo a data_sessao para o formato "dia/mês/ano"
            data_sessao_formatada = data_sessao.strftime("%d/%m/%Y")

            print(f"Filme: {titulo_filme}")
            print(f"Sessão: {hr_inicio.strftime('%H:%M')} - {hr_fim.strftime('%H:%M')} - {data_sessao_formatada}")
            print(f"Cadeira: {nr_cadeira}")
            print(f"Tipo de Ingresso: {'Inteira' if tipo_ingresso == 1 else 'Meia'}")
            print(f"Valor: R$ {valor_ingresso}\n")
            valor_total += valor_ingresso
        else:
            print("Informações do ingresso não disponíveis.\n")

    cursor.close()
    conn.close()

    print(f"Valor Total: R$ {valor_total}")


def menu():
    print('=====Selecione uma opção=====')
    print('1 - Realizar Login')
    print('2 - Realizar Cadastro')
    opcao = int(input())

    if opcao == 1:
        username = input('Email: ')
        password = input('Senha: ')
        if verificar_login(username, password):
            ingressos = []
            while True:
                print('\n')
                id_filme_escolhido = escolher_filme()
                if id_filme_escolhido is not None:
                    print('\n')
                    id_sessao_escolhida = escolher_sessao(id_filme_escolhido)
                    if id_sessao_escolhida is not None:
                        print('\n')
                        nr_cadeira_escolhida = escolher_cadeira(id_sessao_escolhida)
                        print('\n')
                        tipo_ingresso = escolher_tipo_ingresso()
                        ingresso = (id_filme_escolhido, id_sessao_escolhida, nr_cadeira_escolhida, tipo_ingresso)
                        ingressos.append(ingresso)

                resposta = input('Deseja comprar mais ingressos? (S/N): ')
                if resposta.upper() != 'S':
                    break

            # Resumo dos ingressos e valor total
            exibir_resumo_ingresso(ingressos)

        else:
            print('Usuário ou senha incorretos.')
    elif opcao == 2:
        cadastrar()
        print('Cadastro realizado com sucesso!')
    else:
        print('Opção inválida.')


if __name__ == '__main__':
    menu()
